import { HttpClient, HttpParams } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { map, switchMap } from 'rxjs/operators';
import { Carga } from 'src/app/shared';
import { ConfigService } from './config.service';

@Injectable({
  providedIn: 'root'
})
export class CargasService {

  url: string = 'http://rutadelservicio.com/api/v1.0/cargas';
  cargaEndpoint: string = '/cargas';

  constructor(
    private http: HttpClient,
    private configService: ConfigService,
  ) { }

  getCargas(
    origen: number = 0,
    despuesDe: Date | null = null,
    antesDe: Date | null = null,
    jobId: string = '',
    estado: string = '',
    nombreArchivo: string = '',
    tipoCarga: string = '',
  ): Observable<Carga[]> {
    let params = new HttpParams()
      .set('origen', origen)
      .set('despues-de', despuesDe?.toISOString() || '')
      .set('antes-de', antesDe?.toISOString() || '')
      .set('job-id', jobId)
      .set('estado', estado)
      .set('nombre-archivo', nombreArchivo)
      .set('tipo', tipoCarga);

    return this.http.get<Carga[]>(this.url, { params: params });
  }

  getCargaById(id: number): Observable<Carga | undefined> {
    return this.http.get<Carga[]>(this.url).pipe(
      map(cargas => cargas.find(carga => carga.id === id)),
    );
  }

  reversar(carga: Carga): Observable<boolean> {
    return this.configService.getApiUrl().pipe(
      switchMap(url => this.http.put<any>(url + this.cargaEndpoint + '/' + carga.id, { accion: 'reversar' })),
    );
  }

  reprocesar(carga: Carga): Observable<boolean> {
    return this.configService.getApiUrl().pipe(
      switchMap(url => this.http.put<any>(url + this.cargaEndpoint + '/' + carga.id, { accion: 'reprocesar' })),
    );
  }

}
