import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { switchMap } from 'rxjs/operators';
import { Origen } from 'src/app/shared';
import { ConfigService } from './config.service';

@Injectable({
  providedIn: 'root'
})
export class OrigenService {

  endpoint: string = '/origenes';

  url = 'https://02p-fahlogicapp-d01.azurewebsites.net:443/api/TsSyncOrigenesToAzureWs/triggers/manual/invoke?api-version=2020-05-01-preview&sp=%2Ftriggers%2Fmanual%2Frun&sv=1.0&sig=5MmNurkZT1uLGTAULkvo4nsVI9tibYfb6iYhAhTinio';
  

  constructor(
    private http: HttpClient,
    private configService: ConfigService,
  ) { }

  getOrigenes(): Observable<Origen[]> {
    return this.configService.getApiUrl().pipe(
      switchMap(url => this.http.post<Origen[]>(this.url,{
        "Columnas": "APPLICATION_NAME, APPLICATION_SHORT_NAME",
        "Tabla": "[xxbol].[TS_FAH_ORIGENES_ALL]"
    })),
    );

    
  }
} 
