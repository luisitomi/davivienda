export interface RegistroCuadre {
  id: number;
  fecha: Date;
  sucursal: number;
  oficina: number;
  saldoIDONormal: number;
  saldoIDOAdicional: number;
  saldoFAH: number;
  diferencia: number;
}
