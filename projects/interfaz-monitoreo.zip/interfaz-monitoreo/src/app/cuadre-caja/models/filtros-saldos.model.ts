export interface FiltrosSaldos {
  fechaCorte: Date | null;
  sucursal: number | null;
  oficina: string | null;
  cuenta: string | null;
}
