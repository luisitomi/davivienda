export interface Filtros {
  origen: number,
  estado: string,
  despuesDe: Date,
  antesDe: Date,
  jobId: string,
  nombreArchivo: string,
  tipoCarga: string,
}
