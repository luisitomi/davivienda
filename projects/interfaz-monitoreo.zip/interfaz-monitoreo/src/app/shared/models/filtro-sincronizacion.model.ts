export interface FiltroSincronizacion {
  proceso: string;
  estado: string;
  readInicio: Date;
  readFin: Date;
}
