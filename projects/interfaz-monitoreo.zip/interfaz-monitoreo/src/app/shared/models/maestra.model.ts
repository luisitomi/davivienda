export interface Maestra {
    codigo?: string;
    valor?: string;
    tipo?: string;
  }
  