import { CorreccionColumna } from ".";

export interface CorreccionColumnaValores {
    tipoArchivo: string;
    correccionColumna: CorreccionColumna
  /*  constructor() {
        this.tipoArchivo = "";
        this.correccionColumna = new CorreccionColumna();
    }*/
  }
  