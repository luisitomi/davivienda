export interface ResultadoCarga {
  estadoArchivo: string;
  asientosCargados: number;
  asientosRechazados: number;
  asientosAprobados: number;
  asientosPendientes: number;
  log: string;
}
