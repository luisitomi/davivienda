export interface CorreccionColumna {
  columna: string;
  tipo: string;
  valor: string;
}
