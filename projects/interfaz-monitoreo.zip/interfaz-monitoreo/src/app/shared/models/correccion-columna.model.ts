export interface  CorreccionColumna {
  columna: string;
  tipo: string;
  valor: string;
 /* constructor() {
    this.columna = "";
    this.tipo = "";
    this.valor = "";
  } */
}
