export interface FiltroSalida {
  interfaz: string;
  estado: string;
  genInicio: Date;
  genFin: Date;
  readInicio: Date;
  readFin: Date;
  nombreArchivo: string;
}
