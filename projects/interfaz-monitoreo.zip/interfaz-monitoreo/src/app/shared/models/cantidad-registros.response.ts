export interface CantidadRegistros {
  cantidad: number;
}
