export interface ResultadoCierre {
}
