export interface CabeceraAsiento {
  origen: number;
  periodoContable: string;
  numero: string;
  descripcion: string;
  fechaContable: Date;
}
