export interface Oficina {
  VALUE_NAME: string;
  DESCRIPTION_NAME: string;
}
