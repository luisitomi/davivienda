export interface CuentaContable {
  VALUE_NAME: string;
  DESCRIPTION_NAME: string;
}
