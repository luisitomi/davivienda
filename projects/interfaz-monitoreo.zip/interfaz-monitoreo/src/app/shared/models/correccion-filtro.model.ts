export interface CorreccionFiltro {
  columna: string;
  criterio: string;
  valor: string;
}
