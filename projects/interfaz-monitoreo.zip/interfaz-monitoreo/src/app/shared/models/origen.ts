export interface Origen {
  APPLICATION_NAME: string;
  APPLICATION_SHORT_NAME: string;
}
