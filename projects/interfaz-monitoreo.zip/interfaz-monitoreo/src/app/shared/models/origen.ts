export interface Origen {
  ORIGEN: string
  /*APPLICATION_NAME: string;
  APPLICATION_SHORT_NAME: string; */
}
