export interface Sincronizacion {
  id: number;
  fecha: Date;
  proceso: string;
  estado: string;
}
