export interface Sucursal {
  VALUE_NAME: string;
  DESCRIPTION_NAME: string;
}
