export interface Cuenta {
  primerDigito: number;
  VALUE_NAME: string;
  DESCRIPTION_NAME: string;
  moneda: string;
  debito: number;
  credito: number;
  neto: number;
}
