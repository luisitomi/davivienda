export interface Columna {
  nombre: string;
  tipo: string;
}
