export interface TxtLog {
    mensaje: string;
}