export interface EstadoDia {
  id: number;
  fecha: Date;
  estado: string;
  fechaCierre: Date;
  ejecutor: string;
}
