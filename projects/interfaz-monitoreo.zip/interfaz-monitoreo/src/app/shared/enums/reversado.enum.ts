export enum Reversado {
  Error = 'Error',
  Si = 'Y',
  No = 'N',
}
