export enum Reversado {
  Error = 'Error',
  Si = 'Si',
  No = 'No',
}
