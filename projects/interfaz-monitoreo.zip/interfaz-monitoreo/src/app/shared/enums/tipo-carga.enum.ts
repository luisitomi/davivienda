export enum TipoCarga {
  Automatico = 'Automático',
  Manual = 'Manual',
  Reverso = 'Reverso',
}
