export enum Roles {
  AdminCarga = 'DV Administrador de Carga',
  VisorCarga = 'DV Visor de Carga',
}
