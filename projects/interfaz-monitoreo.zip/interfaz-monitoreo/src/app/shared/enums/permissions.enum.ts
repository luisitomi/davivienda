export enum Permissions {
  None = 'Sin permiso',
  View = 'Modo de vista',
  Admin = 'Modo de edición',
}
