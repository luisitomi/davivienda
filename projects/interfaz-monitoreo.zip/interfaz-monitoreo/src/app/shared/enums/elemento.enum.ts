export enum Elemento {
  Cabeceras = 'cabeceras',
  Lineas = 'lineas',
}
