export enum Estados {
  Procesado = 'Procesado',
  ErrorTecnico = 'Error Técnico',
  ErrorFuncional = 'Error Funcional',
}
