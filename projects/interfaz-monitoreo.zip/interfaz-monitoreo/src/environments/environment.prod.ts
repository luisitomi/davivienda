import { devBackendProvider } from "../app/core/interceptors/dev-backend.interceptor";


export const environment = {
  production: true
};

export const INTERCEPTORS = [
  devBackendProvider,
];
